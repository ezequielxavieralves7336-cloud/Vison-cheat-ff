# Vison Security Android — protótipo

Este é um projeto-base Android Studio criado a partir do pedido do usuário.

**Importante:** o ZIP original continha somente `Vison Security.exe` (Windows). Não havia código-fonte para converter. Portanto, este projeto NÃO contém nem reproduz as funções do EXE. Ele oferece apenas um painel Android com checklist manual e recomendações básicas de segurança.

## Como gerar o APK
1. Instale o Android Studio em um computador.
2. Abra a pasta `VisonSecurityAndroid` no Android Studio.
3. Aguarde a sincronização do Gradle e instale os componentes solicitados.
4. Use **Build > Build APK(s)**.
5. O APK de depuração será gerado em `app/build/outputs/apk/debug/`.

Este ambiente não tem Android SDK/Gradle instalado, então não foi possível compilar nem testar um APK aqui.
