package com.vison.security;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private LinearLayout root;
    private TextView status;
    private int blue = Color.rgb(30,136,229);
    private int dark = Color.rgb(16,24,39);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(dark);
        getWindow().setNavigationBarColor(dark);
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(24));
        root.setBackgroundColor(Color.rgb(245,247,251));
        scroll.addView(root);
        setContentView(scroll);

        TextView brand = text("VISON SECURITY", 25, dark, true);
        root.addView(brand);
        TextView subtitle = text("Painel de segurança do dispositivo", 14, Color.DKGRAY, false);
        subtitle.setPadding(0, dp(5), 0, dp(20)); root.addView(subtitle);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackgroundColor(Color.WHITE);
        root.addView(card, new LinearLayout.LayoutParams(-1, -2));
        status = text("Proteção não verificada", 19, dark, true);
        card.addView(status);
        TextView note = text("Esta versão é um protótipo. Ela não executa uma varredura antivírus real.", 14, Color.DKGRAY, false);
        note.setPadding(0, dp(8), 0, dp(14)); card.addView(note);
        Button check = new Button(this); check.setText("Ver checklist de segurança");
        card.addView(check);
        check.setOnClickListener(v -> showChecklist());

        addSection("Recomendações rápidas");
        addInfo("Google Play Protect", "Abra a Play Store > perfil > Play Protect e toque em Verificar.");
        addInfo("Atualizações", "Configurações > Atualização de software. Instale atualizações disponíveis.");
        addInfo("Permissões", "Revise permissões de câmera, microfone, localização e acessibilidade.");
        addInfo("Aplicativos suspeitos", "Desinstale apps que você não reconhece ou que vieram de fontes desconhecidas.");

        Button about = new Button(this); about.setText("Sobre este aplicativo");
        root.addView(about);
        about.setOnClickListener(v -> new android.app.AlertDialog.Builder(this)
            .setTitle("Vison Security — protótipo")
            .setMessage("Este projeto Android foi criado como uma base inicial. O arquivo EXE original não foi convertido e suas funções não estão incluídas. Nenhuma verificação automática é realizada.")
            .setPositiveButton("OK", null).show());
    }

    private void showChecklist() {
        String[] items = {
            "Play Protect verificado",
            "Android atualizado",
            "Bloqueio de tela ativado",
            "Apps desconhecidos revisados",
            "Permissões revisadas"
        };
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        for (String item : items) {
            CheckBox cb = new CheckBox(this); cb.setText(item); box.addView(cb);
        }
        new android.app.AlertDialog.Builder(this).setTitle("Checklist manual")
            .setView(box).setPositiveButton("Concluir", (d,w) -> {
                status.setText("Checklist revisado manualmente");
            }).setNegativeButton("Cancelar", null).show();
    }

    private void addSection(String s) {
        TextView t = text(s, 18, dark, true);
        t.setPadding(0, dp(22), 0, dp(10)); root.addView(t);
    }
    private void addInfo(String title, String body) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(12), dp(14), dp(12)); c.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(10);
        root.addView(c, lp);
        c.addView(text(title, 16, blue, true));
        TextView b = text(body, 14, Color.DKGRAY, false); b.setPadding(0, dp(5), 0, 0); c.addView(b);
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
}
